<?php


/**
 * Description of AL_Helpers
 *
 * @author studio
 */
class AL_Helpers {

    public function __construct() {

    }

}
