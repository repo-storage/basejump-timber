<?php

/**
 * Description of FN_SimpleCaptcha
 *
 * @author shawn sandy
 */

require_once dirname(__FILE__).'/simple-php-captcha.php';

class FN_SimpleCaptcha {

    public function __construct() {

    }

}

?>
