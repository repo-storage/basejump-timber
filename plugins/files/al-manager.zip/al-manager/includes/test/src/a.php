<?php

class A {
}
