<?php

class B
{
}
