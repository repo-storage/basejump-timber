<?php 
/** 
 * AutoloadManager Script
 * 
 * @authors      Al-Fallouji Bashar & Charron Pierrick
 * 
 * @description This file was automatically generated at 2011-12-22 [14:45:57]
 * 
 */ 
return array (
    'A' => __DIR__ . '/src/a.php'
);
