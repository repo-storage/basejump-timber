<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Mod_themes
 *
 * @author studio
 */
abstract class Mod_themes {

    public function __construct() {

    }

}

