<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of AL_Postdata
 *
 * @author studio
 */
class AL_Postdata {

    public function __construct() {

    }

}

?>
