<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of al_test
 *
 * @author Studio365
 */
class al_test {

    public function __construct() {

    }

    public function hello_word($name='world'){
        echo "Hello {$name}";
    }

}

?>
