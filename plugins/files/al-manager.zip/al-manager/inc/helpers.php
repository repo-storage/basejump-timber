<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of helpers
 *
 * @author studio
 */
class helpers {

    public function __construct() {

    }

}

?>
