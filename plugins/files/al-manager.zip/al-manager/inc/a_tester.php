<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of a_tester
 *
 * @author Studio365
 */
class a_tester {

    public function __construct() {

    }

    public function test(){
        echo "a test class";
    }

}

?>
