<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

?>
Cart Total
<p>Sub Total</p>
<p>Coupons</p>
<p>Checkout $</p>