<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<p>Select a coupon to add to this cart</p>
<select name="cts_coupon" style="width: 90%">
    <option></option>
    <option>Coupon / Specials</option>
    <option>Coupon</option>
    <option>Coupon</option>
    <option>---------------------------------</option>
</select>