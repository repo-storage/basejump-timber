phpPayPal Class
=======================

For full documentation and information, please visit the Wiki at GitHub: https://github.com/drewjoh/phpPayPal/wiki

Until I'm moved fully to GibHub, older but more extensive documentation and examples can be found at: http://drewjoh.com/wiki/code/classes/phppaypal
Those examples and code are a little outdated; but should still be helpful.

Created and grown over time by Drew Johnston, drewjoh.com. Please give credit where credit is due. :)

Licensed under the Apache License, Version 2.0